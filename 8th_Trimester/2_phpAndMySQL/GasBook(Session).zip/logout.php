<?php
session_start();

if(isset($_POST['logout']))
  session_destroy();
 ?>
 <html>
 <body bgcolor="beige">
   <h3>"Logout Successful!"</h3>
 </body>
 </html>
