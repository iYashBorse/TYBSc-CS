<?php
  error_reporting(0);
  //Create connection
  $conn = mysqli_connect("localhost", "root", "", "gasbookdb");
  //Check connection
  if (!$conn){
    die("Connection failed: " . mysqli_connect_error());
  }
  $typesOfCylin = mysqli_query($conn,"SELECT * FROM price_details");

?>
<html>

    <head>
        <title>Customer Login</title>
    </head>

    <body bgcolor="beige">

        <form method="POST" action="registration.php">
            Customer number: <input type ="text" name="cusno"/><br><br>
            Name : <input type="text" name="name" /><br><br>
            Address : <input type="text" name="address" /><br><br>
            City : <input type="text" name="city" /><br><br>
            Phone : <input type="number" name="phone" /><br><br>
            Pincode : <input type="number" name="pincode" /><br><br>
            Date of Connection: <input type="text" name="Dtofconn"/><br><br>
            Type Of Cylin : <select name="typeOfCylin">
                <?php
                    while($row = mysqli_fetch_assoc($typesOfCylin)){
                        ?><option value="<?php echo $row["Cylintype"]?>"> <?php echo $row["Cylintype"]?></option><?php
                    }
                ?>
            </select><br><br>
            Password : <input type="password" name="pass" /><br><br>
            <input type="submit"/>&nbsp;&nbsp;&nbsp;<input type="reset"/>

        </form>

    </body>
</html>

<?php
    $Consno = $_POST['cusno'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];
    $password = $_POST['pass'];
    $Dtofconn = $_POST['Dtofconn'];
    $typeOfCylin = $_POST['typeOfCylin'];

    $iQuery = "INSERT INTO customer_details (`Consno`, `Pass`, `Cylintype`, `DtofConn`, `Cname`, `Caddr`, `City`, `Phone`, `Pincode`) VALUES ('$Consno','$password','$typeOfCylin','$Dtofconn','$name','$address','$city','$phone','$pincode')";

    if(mysqli_query($conn,$iQuery)){
        echo "successful";
    }
    else{
        echo "failed";
    }

?>
