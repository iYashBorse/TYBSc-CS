<?php
session_start();
echo "Customer number: ".$_SESSION['Consno']."<br><br>";
 ?>

<html>
<body bgcolor="beige">
<form method="POST" action="booking.php">
    Billing id: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="Blid"/><br><br>
    Booking Date : <input type="text" name="Bkdate" /><br><br>
    Delivery Date : <input type="text" name="Deldate" /><br><br>
    Cylin Type : <?php echo $_COOKIE['Cylintype'] ?><br><br>
    Amount : <?php echo $_COOKIE['price'] ?><br><br>
    <input type="submit" value="Book" />&nbsp;&nbsp;&nbsp;<input type="reset" />
</form>
</body>
</html>

<?php
  error_reporting(0);
//Create connection
$conn = mysqli_connect("localhost", "root", "", "GasBookdb");
//Check connection
if (!$conn){
  die("Connection failed: " . mysqli_connect_error());
}

$Blid = $_POST['Blid'];
$Deldate = $_POST['Deldate'];
$Bkdate = $_POST['Bkdate'];
$Cylintype = $_COOKIE['Cylintype'];
$price = $_COOKIE['price'];
$Consno = $_COOKIE['Consno'];

$iQuery = "INSERT INTO billing_details (`Blid`, `Consno`, `Cylintype`, `Bkdate`, `Deldate`, `Amt`) VALUES ('$Blid','$Consno','$Cylintype','$Bkdate','$Deldate','$price')";

if (mysqli_query($conn, $iQuery)) {
    echo "Booking Success<br>";
    //$bill_id = mysqli_insert_id($conn);

    $result = mysqli_query($conn, "SELECT * FROM billing_details where `Blid` = $Blid");

    $row = mysqli_fetch_assoc($result);

?>
    <html>

    <head>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;
            }
            th,td {
                padding: 15px;
            }
        </style>
    </head>

    <body>
        <table style="text-align: center;">
            <tr>
                <th>Title</th>
                <th>Details</th>
            </tr>
            <tr>
                <td>Booking Date</td>
                <td><?php echo $row['Bkdate']; ?></td>
            </tr>
            <tr>
                <td>Delivery Date</td>
                <td><?php echo $row['Deldate']; ?></td>
            </tr>
            <tr>
                <td>Cylinder Type</td>
                <td><?php echo $row['Cylintype']; ?></td>
            </tr>
            <tr>
                <td>Amount</td>
                <td><?php echo $row['Amt']; ?></td>
            </tr>
        </table>

<?php
} else {
    echo "Booking Failed";
}
?>
<form method="POST" action="logout.php">
<br><br><input type="submit" name="logout" value="Logout"><br>
</form>
</body>
</html>
